package com.example.diplom;

import androidx.appcompat.app.AppCompatActivity;

public class BassTuner extends AppCompatActivity {
    int eTune[];
    BassTuner(){
        eTune = new int[]{98, 73, 55 ,41};
    }

    public String processPitch(int pitch) {
        if (pitch >= 31 && pitch < 47) {
            return "E";
        } else if (pitch >= 48 && pitch < 63) {
            return "A";
        } else if (pitch >= 64 && pitch < 84) {
            return "D";
        } else if ((pitch >= 85 && pitch < 110)) {
            return "G";
        } else {
            return "";
        }
    }

    public String suggestion(int pitch, String note) {
        int requiredHertz = 0;
        int frequencyDifference = 0;
        if(pitch >= 31 && pitch < 110) {
            switch (note) {
                case "G":
                    requiredHertz = eTune[0];
                    break;
                case "D":
                    requiredHertz = eTune[1];
                    break;
                case "A":
                    requiredHertz = eTune[2];
                    break;
                case "E":
                    requiredHertz = eTune[3];
                    break;
            }

            if (pitch >= requiredHertz - 1 && pitch <= requiredHertz + 1) {
                return "Perfect!";
            } else if (pitch <= requiredHertz + 5) {
                frequencyDifference = pitch - requiredHertz;
                return String.valueOf(frequencyDifference);
            } else if (pitch >= requiredHertz) {
                frequencyDifference = pitch - requiredHertz;
                return String.valueOf(frequencyDifference);
            } else if (pitch >= requiredHertz - 5) {
                frequencyDifference = pitch - requiredHertz;
                return String.valueOf(frequencyDifference);
            }
        }
        return "";
    }
}
