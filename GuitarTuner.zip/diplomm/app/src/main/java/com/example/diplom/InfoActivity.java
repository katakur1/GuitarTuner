package com.example.diplom;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class InfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
    }


    public void intentGuitar(View view) {
        Intent intent = new Intent(this, GuitarActivityStandart.class);
        startActivity(intent);
    }

    public void intentBassGuitar(View view) {
        Intent intent = new Intent(this, BassGuitarActivity.class);
        startActivity(intent);
    }

    public void toMetronom(View view) {
        Intent intent = new Intent(this, MetronomActivity.class);
        startActivity(intent);
    }
}