package com.example.diplom;

import androidx.core.app.ActivityCompat;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import be.tarsos.dsp.AudioDispatcher;
import be.tarsos.dsp.AudioEvent;
import be.tarsos.dsp.AudioProcessor;
import be.tarsos.dsp.io.android.AudioDispatcherFactory;
import be.tarsos.dsp.pitch.PitchDetectionHandler;
import be.tarsos.dsp.pitch.PitchDetectionResult;
import be.tarsos.dsp.pitch.PitchProcessor;


public class GuitarActivity extends TunerMain implements AdapterView.OnItemSelectedListener{
    MediaPlayer str1;
    Button Eb, Ab, Db, Gb, Bb, Eb2;

    int Ebc = R.color.black;
    int Abc = R.color.black;
    int Dbc = R.color.black;
    int Gbc = R.color.black;
    int Bbc = R.color.black;
    int Eb2c = R.color.black;

    boolean currentPosition = false;
    TextView possibleHertz;
    TextView possibleString;
    TextView tE2, tB, tG, tD, tA, tE;
    TextView suggestion;
    String note = "";
    TunerMain tM;
    Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ПОДГОТОВЛИВАЕМ Spiner
        spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.guitartunings, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemClickListener(this);
        //

        Eb = findViewById(R.id.E);
        Ab = findViewById(R.id.A);
        Db = findViewById(R.id.D);
        Gb = findViewById(R.id.G);
        Bb = findViewById(R.id.B);
        Eb2 = findViewById(R.id.E2);

        tE2= findViewById(R.id.textHzE2);
        tB= findViewById(R.id.textHzB);
        tG= findViewById(R.id.textHzG);
        tD= findViewById(R.id.textHzD);
        tA= findViewById(R.id.textHzA);
        tE= findViewById(R.id.textHzE);

        String[] arr = {android.Manifest.permission.RECORD_AUDIO};
        possibleHertz = findViewById(R.id.possibleHertz);;
        possibleString = findViewById(R.id.possibleString);
        suggestion = findViewById(R.id.suggestion);


        ActivityCompat.requestPermissions(this,arr, 1);

        AudioDispatcher dispatcher = AudioDispatcherFactory.fromDefaultMicrophone(22050,1024,0);
        PitchDetectionHandler pdh = new PitchDetectionHandler() {
            @Override
            public void handlePitch(PitchDetectionResult res, AudioEvent e) {
                final int pitchInHz = (int) res.getPitch();
                if (pitchInHz != -1) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            note = processPitch(pitchInHz);
                            possibleString.setText(note);
                            possibleHertz.setText(String.valueOf(pitchInHz + " Hz"));
                            suggestion.setText(suggestion(pitchInHz, note));
                        }
                    });
                }
                else {
                    possibleString.setText("");
                    possibleHertz.setText("");
                    suggestion.setText("");
                }
            }
        };
        AudioProcessor pitchProcessor = new PitchProcessor(PitchProcessor.PitchEstimationAlgorithm.FFT_YIN, 22050, 1024, pdh);
        dispatcher.addAudioProcessor(pitchProcessor);

        Thread audioThread = new Thread(dispatcher, "Audio Thread");
        audioThread.start();
    }


    public void Eb(View view) {
        tE2.setText(eTune[0]);
        tB.setText(eTune[1]);
        tG.setText(eTune[2]);
        tD.setText(eTune[3]);
        tA.setText(eTune[4]);
        tE.setText(eTune[5]);
        str1 = MediaPlayer.create(this, R.raw.struna6);
        str1.start();

        if (Ebc == R.color.black && currentPosition == false) {
            Eb.setBackgroundColor(Ebc);
            Ebc = 0x654321;
            currentPosition = true;
        } else {
            Eb.setBackgroundColor(Ebc);
            Ebc = R.color.black;
            currentPosition = false;
        }
    }



    public void Ab(View view) {
        str1 = MediaPlayer.create(this, R.raw.struna5);
        str1.start();

        if(Abc == R.color.black && currentPosition == false){
            Ab.setBackgroundColor(Abc);
            Abc = 0x654321;
            currentPosition = true;
        } else {
            Ab.setBackgroundColor(Abc);
            Abc = R.color.black;
            currentPosition = false;
        }
    }



    public void Db(View view) {
        str1 = MediaPlayer.create(this, R.raw.struna4);
        str1.start();
        if(Dbc == R.color.black && currentPosition == false){
            Db.setBackgroundColor(Dbc);
            Dbc = 0x654321;
            currentPosition = true;
        }else{
            Db.setBackgroundColor(Dbc);
            Dbc = R.color.black;
            currentPosition = false;
        }
    }



    public void Gb(View view) {
        str1 = MediaPlayer.create(this, R.raw.struna3);
        str1.start();
        if(Gbc == R.color.black && currentPosition == false){
            Gb.setBackgroundColor(Gbc);
            Gbc = 0x654321;
            currentPosition = true;
        }else{
            Gb.setBackgroundColor(Gbc);
            Gbc = R.color.black;
            currentPosition = false;
        }
    }



    public void Bb(View view) {
        str1 = MediaPlayer.create(this, R.raw.struna2);
        str1.start();
        if(Bbc == R.color.black && currentPosition == false){
            Bb.setBackgroundColor(Bbc);
            Bbc = 0x654321;
            currentPosition = true;
        }else{
            Bb.setBackgroundColor(Bbc);
            Bbc = R.color.black;
            currentPosition = false;
        }
    }


    public void Eb2(View view) {
        str1 = MediaPlayer.create(this, R.raw.struna1);
        str1.start();
        if(Eb2c == R.color.black && currentPosition  == false ){
            Eb2.setBackgroundColor(Eb2c);
            Eb2c = 0x654321;
            currentPosition = true;
        }else{
            Eb2.setBackgroundColor(Eb2c);
            Eb2c = R.color.black;
            currentPosition = false;
        }
    }

    public void intentGuitar(View view) {

    }

    // ПЕРЕХОД К ДРУГОЙ АКТИВНОСТИ
    public void intentBassGuitar(View view) {
        Intent intent = new Intent(this, BassGuitarActivity.class);
        startActivity(intent);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    //

}