package com.example.diplom;

import androidx.core.app.ActivityCompat;


import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import be.tarsos.dsp.AudioDispatcher;
import be.tarsos.dsp.AudioEvent;
import be.tarsos.dsp.AudioProcessor;
import be.tarsos.dsp.io.android.AudioDispatcherFactory;
import be.tarsos.dsp.pitch.PitchDetectionHandler;
import be.tarsos.dsp.pitch.PitchDetectionResult;
import be.tarsos.dsp.pitch.PitchProcessor;


public class GuitarActivityStandart extends TunerMain implements AdapterView.OnItemSelectedListener {
    MediaPlayer str1;

    Button Eb, Ab, Db, Gb, Bb, Eb2;

    ListView lw;
    private ArrayAdapter<String> arad;

    boolean currentPosition = false;
    boolean sFCheck = true;

    TextView possibleHertz;
    TextView possibleString;
    TextView suggestion;
    String note = "";
    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ПОДГОТОВЛИВАЕМ Spiner
        spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.guitartunings, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setSelection(0);
        spinner.setOnItemSelectedListener(this);
        //

        lw = findViewById(R.id.listview);
        arad = new ArrayAdapter<>(this, R.layout.le);
        lw.setAdapter(arad);
        //

        Eb = findViewById(R.id.D2);
        Ab = findViewById(R.id.A);
        Db = findViewById(R.id.D);
        Gb = findViewById(R.id.G);
        Bb = findViewById(R.id.B);
        Eb2 = findViewById(R.id.E2);

        possibleHertz = findViewById(R.id.possibleHertzDropD);

        possibleString = findViewById(R.id.possibleStringDropD);
        suggestion = findViewById(R.id.suggestionDropD);

        // Разрешения использования аудио
        String[] arr = {android.Manifest.permission.RECORD_AUDIO};
        ActivityCompat.requestPermissions(this, arr, 1);

        AudioDispatcher dispatcher = AudioDispatcherFactory.fromDefaultMicrophone(22050, 1024, 0);
        PitchDetectionHandler pdh = new PitchDetectionHandler() {
            @Override
            public void handlePitch(PitchDetectionResult res, AudioEvent e) {
                final int pitchInHz = (int) res.getPitch();
                if (pitchInHz != -1) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            note = processPitchETune(pitchInHz);
                            possibleString.setText(note);
                            possibleHertz.setText(String.valueOf(pitchInHz + " Hz"));
                            if(suggestionEtune(pitchInHz, note) == "Perfect!") {
                                suggestion.setTextColor(Color.rgb(50, 205, 50));
                                suggestion.setText(suggestionEtune(pitchInHz, note));
                            } else {
                                suggestion.setTextColor(Color.rgb(0, 0, 0));
                                suggestion.setText(suggestionEtune(pitchInHz, note));
                            }
                        }
                    });
                } else {
                    possibleString.setText("");
                    suggestion.setText("");
                }
            }
        };
        try {
            AudioProcessor pitchProcessor = new PitchProcessor(PitchProcessor.PitchEstimationAlgorithm.FFT_YIN, 22050, 1024, pdh);
            dispatcher.addAudioProcessor(pitchProcessor);

            Thread audioThread = new Thread(dispatcher, "Audio Thread");
            audioThread.start();
        } catch (Exception e){

        }
    }


    public void Eb(View view) {
        str1 = MediaPlayer.create(this, R.raw.struna6);
        str1.start();

    }


    public void Ab(View view) {
        str1 = MediaPlayer.create(this, R.raw.struna5);
        str1.start();

    }


    public void Db(View view) {
        str1 = MediaPlayer.create(this, R.raw.struna4);
        str1.start();
    }


    public void Gb(View view) {
        str1 = MediaPlayer.create(this, R.raw.struna3);
        str1.start();
    }


    public void Bb(View view) {
        str1 = MediaPlayer.create(this, R.raw.struna2);
        str1.start();
    }


    public void Eb2(View view) {
        str1 = MediaPlayer.create(this, R.raw.struna1);
        str1.start();
    }

    public void intentGuitar(View view) {

    }

    // ПЕРЕХОД К ДРУГОЙ АКТИВНОСТИ
    public void intentBassGuitar(View view) {
        Intent intent = new Intent(this, BassGuitarActivity.class);
        startActivity(intent);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String tuneName = parent.getItemAtPosition(position).toString();

        if(tuneName.equals("Drop D")){
            Intent intent = new Intent(this, GuitarActivityDropD.class);
            startActivity(intent);
        }

        if(tuneName.equals("Open D")){
            Intent intent = new Intent(this, GuitarActivityOpenD.class);
            startActivity(intent);
        }
    }


    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void sF(View view) {
        if(sFCheck) {
            String standDArray[] = getResources().getStringArray(R.array.Standart);
            arad.addAll(standDArray);
            sFCheck = false;
        } else {
            arad.clear();
            sFCheck = true;
        }
    }

    public void toMetronom(View view) {
        Intent intent = new Intent(this, MetronomActivity.class);
        startActivity(intent);
    }

    public void infoIntent(View view) {
        Intent intent = new Intent(this, InfoActivity.class);
        startActivity(intent);
    }

    //

}