package com.example.diplom;

import androidx.core.app.ActivityCompat;

import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import be.tarsos.dsp.AudioDispatcher;
import be.tarsos.dsp.AudioEvent;
import be.tarsos.dsp.AudioProcessor;
import be.tarsos.dsp.io.android.AudioDispatcherFactory;
import be.tarsos.dsp.pitch.PitchDetectionHandler;
import be.tarsos.dsp.pitch.PitchDetectionResult;
import be.tarsos.dsp.pitch.PitchProcessor;

public class BassGuitarActivity extends BassTuner {
    Spinner spinner;
    MediaPlayer mP;
    TextView possibleHertz;
    TextView possibleString;
    TextView suggestion;
    String note = "";
    ListView lw;
    private ArrayAdapter<String> arad;

    boolean sFCheck = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bass_guitar);

        // ПОДГОТОВЛИВАЕМ Spiner
        spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.bassguitartunings, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        //

        // Заполняем ListView
        lw = findViewById(R.id.listview);
        arad = new ArrayAdapter<>(this, R.layout.le);
        lw.setAdapter(arad);
        //

        possibleHertz = findViewById(R.id.possibleHertz2);
        possibleString = findViewById(R.id.possibleString2);
        suggestion = findViewById(R.id.suggestion2);


        AudioDispatcher dispatcher = AudioDispatcherFactory.fromDefaultMicrophone(22050,1024,0);
        PitchDetectionHandler pdh = new PitchDetectionHandler() {
            @Override
            public void handlePitch(PitchDetectionResult res, AudioEvent e) {
                final int pitchInHz = (int) res.getPitch();
                if (pitchInHz != -1) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            note = processPitch(pitchInHz);
                            possibleString.setText(note);
                            possibleHertz.setText(String.valueOf(pitchInHz + " Hz"));
                            if(suggestion(pitchInHz, note) == "Perfect!") {
                                suggestion.setTextColor(Color.rgb(50, 205, 50));
                                suggestion.setText(suggestion(pitchInHz, note));
                            } else {
                                suggestion.setTextColor(Color.rgb(0, 0, 0));
                                suggestion.setText(suggestion(pitchInHz, note));
                            }
                        }
                    });
                }
                else {
                    possibleString.setText("");
                    possibleHertz.setText("");
                    suggestion.setText("");
                }
            }
        };
        AudioProcessor pitchProcessor = new PitchProcessor(PitchProcessor.PitchEstimationAlgorithm.FFT_YIN, 22050, 1024, pdh);
        dispatcher.addAudioProcessor(pitchProcessor);

        Thread audioThread = new Thread(dispatcher, "Audio Thread");
        audioThread.start();
    }

    public void Gbut(View view) {

    }

    public void Dbut(View view) {

    }

    public void Abut(View view) {

    }

    public void Ebut(View view) {

    }

    public void sF(View view) {
        if(sFCheck) {
            String openDArray[] = getResources().getStringArray(R.array.StandartBass);
            arad.addAll(openDArray);
            sFCheck = false;
        } else {
            arad.clear();
            sFCheck = true;
        }
    }

    public void intentGuitar(View view) {
        Intent intent = new Intent(this, GuitarActivityStandart.class);
        startActivity(intent);
    }

    public void toMetronom(View view) {
        Intent intent = new Intent(this, MetronomActivity.class);
        startActivity(intent);
    }

    public void infoIntent(View view) {
        Intent intent = new Intent(this, InfoActivity.class);
        startActivity(intent);
    }

}