package com.example.diplom;

import androidx.appcompat.app.AppCompatActivity;

public class TunerMain extends AppCompatActivity {
    public int eTune[]; // Строй E
    public int dropDTune[]; // Строй Eb ми бемоль
    public int openDTune[];

    TunerMain(){
        eTune = new int[]{330, 247, 196, 147, 110, 82};
        dropDTune = new int[]{330, 247, 196, 147, 110, 74};
        openDTune = new int[]{294, 220, 185, 148, 110, 74};
    }

    // Методы для STANDART
    public String processPitchETune(int pitch) {
        if (pitch >= 70 && pitch < 96) {
            return "E";
        } else if (pitch >= 96 && pitch < 128) {
            return "A";
        } else if (pitch >= 128 && pitch < 171) {
            return "D";
        } else if (pitch >= 171 && pitch < 221) {
            return "G";
        } else if (pitch >= 221 && pitch < 300) {
            return "B";
        } else if ((pitch >= 300 && pitch < 345)) {
            return "E2";
        } else {
            return "";
        }
    }

    public String suggestionEtune(int pitch, String note) {
        int requiredHertz = 0;
        int frequencyDifference = 0;
        if(pitch >= 70 && pitch < 345) {
            switch (note) {
                case "E2":
                    requiredHertz = eTune[0];
                    break;
                case "B":
                    requiredHertz = eTune[1];
                    break;
                case "G":
                    requiredHertz = eTune[2];
                    break;
                case "D":
                    requiredHertz = eTune[3];
                    break;
                case "A":
                    requiredHertz = eTune[4];
                    break;
                case "E":
                    requiredHertz = eTune[5];
                    break;
            }


            if (pitch >= requiredHertz - 1 && pitch <= requiredHertz + 1) {
                return "Perfect!";
            } else if (pitch <= requiredHertz + 5) {
                frequencyDifference = pitch - requiredHertz;
                return String.valueOf(frequencyDifference);
            } else if (pitch >= requiredHertz) {
                frequencyDifference = pitch - requiredHertz;
                return String.valueOf(frequencyDifference);
            } else if (pitch >= requiredHertz - 5) {
                frequencyDifference = pitch - requiredHertz;
                return String.valueOf(frequencyDifference);
            }
        }
        return "";
    }
////////////////////////////////////////////////////////////////////////////////////////
    // Методы для Drop D

    public String processPitchDropD(int pitch) {
        if (pitch >= 64 && pitch < 96) {
            return "D2";
        } else if (pitch >= 96 && pitch < 128) {
            return "A";
        } else if (pitch >= 128 && pitch < 171) {
            return "D";
        } else if (pitch >= 171 && pitch < 221) {
            return "G";
        } else if (pitch >= 221 && pitch < 300) {
            return "B";
        } else if ((pitch >= 300 && pitch < 345)) {
            return "E2";
        } else {
            return "";
        }
    }

    public String suggestionDropD(int pitch, String note) {
        int requiredHertz = 0;
        int frequencyDifference = 0;
        if(pitch >= 64 && pitch < 345) {
            switch (note) {
                case "E2":
                    requiredHertz = dropDTune[0];
                    break;
                case "B":
                    requiredHertz = dropDTune[1];
                    break;
                case "G":
                    requiredHertz = dropDTune[2];
                    break;
                case "D":
                    requiredHertz = dropDTune[3];
                    break;
                case "A":
                    requiredHertz = dropDTune[4];
                    break;
                case "D2":
                    requiredHertz = dropDTune[5];
                    break;
            }


            if (pitch >= requiredHertz - 1 && pitch <= requiredHertz + 1) {
                return "Perfect!";
            } else if (pitch <= requiredHertz + 5) {
                frequencyDifference = pitch - requiredHertz;
                return String.valueOf(frequencyDifference);
            } else if (pitch >= requiredHertz) {
                frequencyDifference = pitch - requiredHertz;
                return String.valueOf(frequencyDifference);
            } else if (pitch >= requiredHertz - 5) {
                frequencyDifference = pitch - requiredHertz;
                return String.valueOf(frequencyDifference);
            }
        }
        return "";
    }
    ///////////////////////////////////////////////////////////////////
    //  Методы Open D

    public String processPitchOpenD(int pitch) {
        if (pitch >= 0 && pitch < 96) {
            return "D";
        } else if (pitch >= 96 && pitch < 135) {
            return "A";
        } else if (pitch >= 135 && pitch < 170) {
            return "D2";
        } else if (pitch >= 170 && pitch < 200) {
            return "F#";
        } else if (pitch >= 200 && pitch < 275) {
            return "A2";
        } else if ((pitch >= 275 && pitch < 305)) {
            return "D3";
        } else {
            return "";
        }
    }

    public String suggestionOpenD(int pitch, String note) {
        int requiredHertz = 0;
        int frequencyDifference = 0;
        if(pitch >= 0 && pitch < 350) {
            switch (note) {
                case "D3":
                    requiredHertz = openDTune[0];
                    break;
                case "A2":
                    requiredHertz = openDTune[1];
                    break;
                case "F#":
                    requiredHertz = openDTune[2];
                    break;
                case "D2":
                    requiredHertz = openDTune[3];
                    break;
                case "A":
                    requiredHertz = openDTune[4];
                    break;
                case "D":
                    requiredHertz = openDTune[5];
                    break;
            }


            if (pitch >= requiredHertz - 1 && pitch <= requiredHertz + 1) {
                return "Perfect!";
            } else if (pitch <= requiredHertz + 5) {
                frequencyDifference = pitch - requiredHertz;
                return String.valueOf(frequencyDifference);
            } else if (pitch >= requiredHertz) {
                frequencyDifference = pitch - requiredHertz;
                return String.valueOf(frequencyDifference);
            } else if (pitch >= requiredHertz - 5) {
                frequencyDifference = pitch - requiredHertz;
                return String.valueOf(frequencyDifference);
            }
        }
        return "";
    }
}
