package com.example.diplom;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import be.tarsos.dsp.AudioDispatcher;
import be.tarsos.dsp.AudioEvent;
import be.tarsos.dsp.AudioProcessor;
import be.tarsos.dsp.io.android.AudioDispatcherFactory;
import be.tarsos.dsp.pitch.PitchDetectionHandler;
import be.tarsos.dsp.pitch.PitchDetectionResult;
import be.tarsos.dsp.pitch.PitchProcessor;

public class GuitarActivityOpenD extends TunerMain implements AdapterView.OnItemSelectedListener {
    Spinner spinner;
    String note = "";
    TextView possibleHertz, possibleString, suggestion;
    private ArrayAdapter<String> arad;
    ListView lw;

    boolean sFCheck = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guitar_open_d);

        // Привязываем TextView Элементы
        possibleHertz = findViewById(R.id.possibleHertzDropD);
        possibleString = findViewById(R.id.possibleStringDropD);
        suggestion = findViewById(R.id.suggestionDropD);
        //

        // Заполняем ListView
        lw = findViewById(R.id.listview);
        arad = new ArrayAdapter<>(this, R.layout.le);
        lw.setAdapter(arad);
        //

        // ПОДГОТОВЛИВАЕМ Spiner
        spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.guitartunings, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setSelection(2);
        spinner.setOnItemSelectedListener(this);
        //

        AudioDispatcher dispatcher = AudioDispatcherFactory.fromDefaultMicrophone(22050, 1024, 0);
        PitchDetectionHandler pdh = new PitchDetectionHandler() {
            @Override
            public void handlePitch(PitchDetectionResult res, AudioEvent e) {
                final int pitchInHz = (int) res.getPitch();
                if (pitchInHz != -1) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            note = processPitchOpenD(pitchInHz);
                            possibleString.setText(note);
                            possibleHertz.setText(String.valueOf(pitchInHz + " Hz"));
                            if(suggestionOpenD(pitchInHz, note) == "Perfect!") {
                                suggestion.setTextColor(Color.rgb(50, 205, 50));
                                suggestion.setText(suggestionOpenD(pitchInHz, note));
                            } else {
                                suggestion.setTextColor(Color.rgb(0, 0, 0));
                                suggestion.setText(suggestionOpenD(pitchInHz, note));
                            }
                        }
                    });
                } else {
                    possibleString.setText("");
                    suggestion.setText("");
                }
            }
        };
        try {
            AudioProcessor pitchProcessor = new PitchProcessor(PitchProcessor.PitchEstimationAlgorithm.FFT_YIN, 22050, 1024, pdh);
            dispatcher.addAudioProcessor(pitchProcessor);

            Thread audioThread = new Thread(dispatcher, "Audio Thread");
            audioThread.start();
        } catch (Exception e) {

        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String tuneName = parent.getItemAtPosition(position).toString();

        if (tuneName.equals("Standart")) {
            Intent intent = new Intent(this, GuitarActivityStandart.class);
            startActivity(intent);
        }

        if (tuneName.equals("Drop D")) {
            Intent intent = new Intent(this, GuitarActivityDropD.class);
            startActivity(intent);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void sF(View view) {
        if(sFCheck) {
            String openDArray[] = getResources().getStringArray(R.array.OpenD);
            arad.addAll(openDArray);
            sFCheck = false;
        } else {
            arad.clear();
            sFCheck = true;
        }
    }

    public void toMetronom(View view) {
        Intent intent = new Intent(this, MetronomActivity.class);
        startActivity(intent);
    }

    public void intentBassGuitar(View view) {
        Intent intent = new Intent(this, BassGuitarActivity.class);
        startActivity(intent);
    }
    public void infoIntent(View view) {
        Intent intent = new Intent(this, InfoActivity.class);
        startActivity(intent);
    }
}