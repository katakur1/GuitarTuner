package com.example.diplom;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

public class MetronomActivity extends AppCompatActivity {
    SoundPool soundPool;
    Button plusOne, minusOne;
    TextView textViewBpm;
    SeekBar seekBar;
    Switch switchOnOff;
    int soundIdTick;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_metronom);
        plusOne = findViewById(R.id.plusOne);
        minusOne = findViewById(R.id.minusOne);
        textViewBpm = findViewById(R.id.textViewBpm);
        switchOnOff = findViewById(R.id.switchOnOff);
        seekBar = findViewById(R.id.seekBar);
        soundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
        soundIdTick = soundPool.load(this, R.raw.tick_500ms, 1);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                playSound(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
            
        });

        switchOnOff.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    playSound(seekBar.getProgress());
                }
                else {
                    soundPool.autoPause();
                }
            }
        });
    }


    private void playSound(int progress){
        int bpm = progress + 30;
        textViewBpm.setText(Integer.toString(bpm));
        float rate = bpm/60f;
        rate /= 2;

        if(switchOnOff.isChecked())
            soundPool.play(soundIdTick, 1, 1, 0, -1, rate);
    }

    public void minusOneLst(View view) {
        seekBar.setProgress(seekBar.getProgress()-1);
    }

    public void plusOneLst(View view) {
        seekBar .setProgress(seekBar.getProgress()+1);
    }

    public void intentGuitar(View view) {
        Intent intent = new Intent(this, GuitarActivityStandart.class);
        startActivity(intent);
    }

    public void intentBass(View view) {
        Intent intent = new Intent(this, BassGuitarActivity.class);
        startActivity(intent);
    }

    public void infoIntent(View view) {
        Intent intent = new Intent(this, InfoActivity.class);
        startActivity(intent);
    }
}

